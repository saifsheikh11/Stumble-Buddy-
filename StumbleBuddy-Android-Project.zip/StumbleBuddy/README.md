# Stumble Buddy — Android companion app

A colourful, fan-made Android companion app for Stumble Guys. It includes:
- General map guides and gameplay tips
- A manual checklist for checking official rewards
- Links to the official shop, news and help centre
- An update tracker that opens official announcements

It does **not** modify Stumble Guys, inject code, automate gameplay, generate gems, or unlock paid items. It is not affiliated with or endorsed by Scopely.

## Build an APK in Android Studio
1. Install Android Studio on a computer and ensure JDK 17 is configured.
2. Open this `StumbleBuddy` project folder.
3. Allow Gradle sync and install any requested Android SDK platform (API 35).
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will usually be at `app/build/outputs/apk/debug/app-debug.apk`.

Requirements: Android Gradle Plugin 8.6.1, Gradle 8.7+, JDK 17, Android SDK 35. Internet is needed on first build to download Gradle/plugin dependencies.

## Install
Transfer the built `app-debug.apk` to your Android phone and install it. Android may ask you to allow installation from that source. Only install APKs you built or trust.
