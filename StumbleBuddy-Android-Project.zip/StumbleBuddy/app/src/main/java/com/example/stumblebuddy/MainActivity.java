package com.example.stumblebuddy;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(247, 246, 255);
    private final int ink = Color.rgb(35, 31, 68);
    private final int purple = Color.rgb(108, 77, 255);
    private final int pink = Color.rgb(255, 91, 145);
    private final int teal = Color.rgb(39, 190, 174);
    private LinearLayout root, content, nav;
    private String active = "Home";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(48, 32, 111));
        getWindow().setNavigationBarColor(Color.rgb(23, 20, 46));
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        setContentView(root);
        buildShell(); showPage("Home");
    }

    private void buildShell() {
        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20), dp(18), dp(20), dp(18));
        header.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(99, 65, 255), Color.rgb(255, 78, 149)}));
        TextView brand = text("🎮  STUMBLE BUDDY", 22, Color.WHITE, true);
        TextView subtitle = text("Your colourful companion guide", 13, Color.WHITE, false);
        subtitle.setAlpha(.92f); header.addView(brand); header.addView(subtitle);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(16), dp(14), dp(16), dp(22));
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        nav = new LinearLayout(this); nav.setPadding(dp(6), dp(7), dp(6), dp(7)); nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(Color.WHITE); root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        String[] tabs = {"Home", "Maps", "Rewards", "Tips", "Updates"};
        for (String tab : tabs) {
            Button b = new Button(this); b.setText(tab); b.setTextSize(10); b.setAllCaps(false); b.setPadding(dp(3), 0, dp(3), 0);
            b.setMinWidth(0); b.setMinimumWidth(0); b.setTextColor(tab.equals(active) ? purple : ink);
            b.setBackgroundColor(Color.TRANSPARENT);
            b.setOnClickListener(v -> showPage(tab));
            nav.addView(b, new LinearLayout.LayoutParams(0, dp(46), 1));
        }
    }

    private void showPage(String page) {
        active = page; content.removeAllViews(); nav.removeAllViews();
        String[] tabs = {"Home", "Maps", "Rewards", "Tips", "Updates"};
        for (String tab : tabs) {
            Button b = new Button(this); b.setText(tab); b.setTextSize(10); b.setAllCaps(false); b.setPadding(dp(2), 0, dp(2), 0);
            b.setMinWidth(0); b.setMinimumWidth(0); b.setTextColor(tab.equals(active) ? purple : ink); b.setBackgroundColor(Color.TRANSPARENT);
            b.setOnClickListener(v -> showPage(tab)); nav.addView(b, new LinearLayout.LayoutParams(0, dp(46), 1));
        }
        switch (page) {
            case "Home": home(); break;
            case "Maps": maps(); break;
            case "Rewards": rewards(); break;
            case "Tips": tips(); break;
            case "Updates": updates(); break;
        }
    }

    private void home() {
        card("👋 Hey Stumbler!", "Use this fan-made companion to learn maps, track reward checks and open official game pages.", purple);
        card("🏁 Map Guides", "Quick strategies for race, survival and team rounds.", teal);
        card("🎁 Free Rewards", "Check the official shop and in-game events. Rewards vary by account and region.", pink);
        card("🔄 Update Tracker", "Open official news to review patch notes and event announcements.", Color.rgb(255, 174, 52));
        note("Not an official Scopely app. It does not modify the game, generate currency or unlock paid items.");
        action("Open official Stumble Guys website", "https://www.stumbleguys.com");
    }

    private void maps() {
        heading("🗺️ Map Guidebook", "Quick, general strategies. Exact routes can change with map updates.");
        card("🏃 Race maps", "• Look ahead instead of only at your character.\n• Use short, controlled jumps on narrow platforms.\n• Dive only when it helps clear a gap or recover momentum.\n• If you fall behind, choose a safe route over a risky shortcut.", purple);
        card("🧊 Moving platforms", "• Pause briefly to read the platform rhythm.\n• Aim for the centre of moving platforms.\n• Avoid jumping while landing space is crowded.", teal);
        card("⚡ Survival rounds", "• Keep moving and watch the next hazard.\n• Stay near open space instead of getting trapped at an edge.\n• Save defensive abilities for a real threat when available.", pink);
        card("🤝 Team rounds", "• Focus on the objective, not just chasing players.\n• Help protect your team's lead and communicate if playing with friends.", Color.rgb(255, 174, 52));
    }

    private void rewards() {
        heading("🎁 Official Rewards Tracker", "Use the checkboxes as a reminder. This app cannot see your account or confirm a claim.");
        check("Checked the in-game Shop for free items");
        check("Checked current Events and Missions");
        check("Reviewed official promo announcements");
        check("Checked whether a free offer wall is available in my game");
        check("Read reward expiry and eligibility rules");
        action("Open official Web Shop", "https://www.stumbleguys.com/shop");
        action("Open official news", "https://www.stumbleguys.com/news");
        note("Never share your password or OTP with gem generators or unofficial reward sites. No active promo code is guaranteed here.");
    }

    private void tips() {
        heading("🎮 Controls & Tips", "Settings differ by device and game version. Try these in practice first.");
        card("🎯 Controls", "• Choose a button layout that keeps jump and dive easy to reach.\n• Avoid changing sensitivity repeatedly; test one change at a time.\n• Practise timing before trying risky shortcuts.", purple);
        card("📱 Phone performance", "• Close heavy background apps before playing.\n• Keep enough free storage and install game updates from Google Play.\n• If the phone heats up, take a break and let it cool.", teal);
        card("🛡️ Account safety", "• Avoid mod APKs, injectors and fake currency tools.\n• Never give login codes to anyone.\n• Use official support for account issues.", pink);
        note("Companion app only: no overlays, game-file changes or automatic gameplay actions.");
    }

    private void updates() {
        heading("🔄 Update Tracker", "This page links to official announcements; it does not automatically detect installed game versions.");
        card("📣 Official News", "Check release notes, season details, event dates and gameplay changes from the developer.", purple);
        action("Open official Stumble Guys News", "https://www.stumbleguys.com/news");
        action("Open official Help Center", "https://stumbleguys.helpshift.com/hc/en/");
        action("Find the game on Google Play", "https://play.google.com/store/apps/details?id=com.kitkagames.fallbuddies");
        note("Update the game through Google Play. Re-check map tips after major updates because gameplay can change.");
    }

    private void heading(String title, String subtitle) {
        TextView h = text(title, 22, ink, true); h.setPadding(0, dp(4), 0, dp(5)); content.addView(h);
        TextView s = text(subtitle, 13, Color.rgb(101, 97, 126), false); s.setPadding(0, 0, 0, dp(12)); content.addView(s);
    }

    private void card(String title, String body, int accent) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(15), dp(13), dp(15), dp(14));
        GradientDrawable shape = new GradientDrawable(); shape.setColor(Color.WHITE); shape.setCornerRadius(dp(18)); shape.setStroke(dp(1), Color.rgb(232, 229, 247)); box.setBackground(shape);
        View stripe = new View(this); stripe.setBackgroundColor(accent); box.addView(stripe, new LinearLayout.LayoutParams(dp(38), dp(4)));
        TextView h = text(title, 17, ink, true); h.setPadding(0, dp(8), 0, dp(5)); box.addView(h);
        TextView b = text(body, 14, Color.rgb(76, 72, 99), false); b.setLineSpacing(dp(3), 1f); box.addView(b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(11); content.addView(box, lp);
    }

    private void check(String label) {
        CheckBox cb = new CheckBox(this); cb.setText(label); cb.setTextColor(ink); cb.setTextSize(14); cb.setPadding(dp(5), dp(7), dp(5), dp(7));
        cb.setButtonTintList(android.content.res.ColorStateList.valueOf(purple));
        GradientDrawable shape = new GradientDrawable(); shape.setColor(Color.WHITE); shape.setCornerRadius(dp(13)); shape.setStroke(dp(1), Color.rgb(232, 229, 247)); cb.setBackground(shape);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(8); content.addView(cb, lp);
    }

    private void action(String label, String url) {
        Button b = new Button(this); b.setText(label + "  ↗"); b.setAllCaps(false); b.setTextSize(14); b.setTextColor(Color.WHITE); b.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable shape = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{purple, pink}); shape.setCornerRadius(dp(14)); b.setBackground(shape);
        b.setOnClickListener(v -> openUrl(url));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(9); content.addView(b, lp);
    }

    private void note(String message) {
        TextView t = text("ℹ️  " + message, 12, Color.rgb(91, 84, 123), false); t.setPadding(dp(4), dp(8), dp(4), dp(12)); t.setLineSpacing(dp(2), 1f); content.addView(t);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { Toast.makeText(this, "Could not open link. Check your browser.", Toast.LENGTH_SHORT).show(); }
    }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
